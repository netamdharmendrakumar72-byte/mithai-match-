# Mithai Match — APK banane ka tareeka

Ye poora project ready hai. Game already `www/index.html` mein hai — 100% offline
chalta hai (koi internet, koi Claude branding nahi). Bas neeche steps follow karo
apne computer par (Windows/Mac/Linux):

## Ek baar ka setup
1. **Node.js** install karo (nodejs.org se, LTS version).
2. **Android Studio** install karo (developer.android.com/studio se) — isme
   Android SDK khud aa jaata hai.

## APK banana
Is folder ko apne computer par kisi jagah rakho, phir terminal/cmd mein:

```bash
cd mithai-match-app
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Aakhri command Android Studio khol dega. Usme:

1. Upar menu se **Build → Build Bundle(s) / APK(s) → Build APK(s)** click karo.
2. Build complete hone par "locate" link milega — wahi tumhari `.apk` file hai
   (`android/app/build/outputs/apk/debug/app-debug.apk`).
3. Ye APK phone mein daal ke install karo — icon tap karte hi seedha game
   khulega, koi browser ya Claude UI nahi dikhega, aur bina internet ke chalega.

## Play Store par upload karne ke liye (zaroori)
Store par upload karne ke liye APK ko **sign** karna padta hai (debug APK store
accept nahi karta):
1. Android Studio mein **Build → Generate Signed Bundle / APK** choose karo.
2. **Android App Bundle (.aab)** banao (Play Store ab yahi maangta hai).
3. Ek keystore banao (pehli baar) — password safe rakhna, dobara nahi milega.
4. Bana hua `.aab` file **Play Console** (play.google.com/console) par upload
   karo — $25 one-time developer account fee lagti hai.

## App ka naam/icon badalna
- Naam: `capacitor.config.json` mein `"appName"` badal do.
- Icon: `resources/icon.png` (1024x1024) daal ke `npx cap sync` chalao — ya
  Android Studio ke andar `res/mipmap` folders mein directly icon daal do.
